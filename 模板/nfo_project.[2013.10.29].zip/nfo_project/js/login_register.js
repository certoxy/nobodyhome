(function(b,c){var $=b.jQuery||b.Y||(b.Y={}),a;$.throttle=a=function(e,f,j,i){var h,d=0;if(typeof f!=="boolean"){i=j;j=f;f=c}function g(){var o=this,m=+new Date()-d,n=arguments;function l(){d=+new Date();j.apply(o,n)}function k(){h=c}if(i&&!h){l()}h&&clearTimeout(h);if(i===c&&m>e){l()}else{if(f!==true){h=setTimeout(i?k:l,i===c?e-m:e)}}}if($.guid){g.guid=j.guid=j.guid||$.guid++}return g};$.debounce=function(d,e,f){return f===c?a(d,e,false):a(d,f,e!==false)}}).call(this, this);

;(function ($, window, document, undefined) {
  function log(msg) {
    var id   = function (x) { return x; },
        puts = window.console && console.log || id,
        ws   = ' ';

    msg = ((window.JSON || window.jQuery || {})['stringify'] || id)(msg, null, 2);

    if (puts === id || typeof puts === 'object') {
      puts(msg);
    } else {
      msg = ws + msg + ws;
      puts.call(console, '\n%c [phantom] $ %c' + msg + '\n', 'color:#259185; background:#042029; font-weight:bold;', 'color:#259185; background:#0A2933');
    }
  }

  function setupTabs() {
    var showMethod = 'fadeIn',
        speed = 'normal';

    function autoFocus() {
      $(this).find(':input:first').focus();
    }

    $('.tabs-wrapper')
      .each(function() {
        $(this)
          .find(".tab-content")
          .hide()
          .eq(0)
            [showMethod](speed, autoFocus)
            .end()
          .end()
          .find('.tabs li:first')
            .addClass('active');
      })
      .on('click', '.tabs a', function () {
        var self = $(this),
            activeTab = self.attr('href'),
            parentList = self.closest('li');

        if (parentList.hasClass('active')) {
          return false;
        }

        parentList
          .addClass('active')
          .siblings()
            .removeClass('active');

        self
          .closest('.tabs-wrapper')
            .find('.tab-content')
              .hide()
              .end()
            .find(activeTab)
              [showMethod](speed, autoFocus);

        return false;
      });

    $('a[href=' + document.location.hash + ']').click();
  }

  function toggleState(target, state, content) {
    var $form = $(target[0].form);

    target.html(content);

    switch (state) {
    case 'busy':
      target
        .prop('disabled', true)
        .addClass('busy');

      $form
        .data('busy', true)
        .on('focus', 'input', function () {
          $(this).blur(); // 阻止获焦
        });
      break;
    case 'idle':
      target
        .prop('disabled', false)
        .removeClass('busy');

      $form
        .removeData('busy')
        .off('focus', 'input');
      break;
    }

    return target;
  }

  // 将表单数据json化
  function jsonedForm(form) {
    var result = {};

    $.each($(form).serializeArray(), function (_, Y) {
      var name = Y.name, value = Y.value || '';

      if (result[name] != null) {
        if (!$.isArray(result[name])) {
          result[name] = [result[name]];
        }
        result[name].push(value);
      } else {
        result[name] = value;
      }
    });

    return result;
  }

  // ajax提交表单
  function ajaxSubmit(form) {
    // 返回的是一个promise对象
    return log(jsonedForm(form));
    return $.ajax({
      url : form.action,
      type: form.method,
      data: jsonedForm(form)
    });
  }

  function prependIcon(o, prefix) {
    var result = {};

    $.each(o, function (_, item) {
      $.each(item, function (k, v) {
        item[k] = prefix + v;
      });

      result[_] = item;
    });

    return result;
  }

  function setupLoginFormValidation() {
    var $loginForm = $('#loginForm').keydown(function (e) {
      e.keyCode === 13 && submitForm();
    }).on('click', 'i.icon', function () {
      $(this).prevAll('input:first').focus();
    });

    $('#login_submit').click(submitForm);

    function submitForm() {
      $loginForm.submit();
      return false;
    }

    $loginForm.validate({
      debug: false,
      focusInvalid: true,
      focusCleanup: false,
      rules: {
        email: {
          required: true,
          email: true
        },
        password: {
          required: true
        },
        token_code: {
          required: true
        }
      },
      messages: prependIcon({
        email: {
          required: '登录邮箱不能为空',
          email: '请输入有效邮箱'
        },
        password: {
          required: '请输入6-16位密码',
          minlength: '请至少输入6位密码'
        },
        token_code: {
          required: '验证码不能为空',
          minlength: '请输入4位验证码'
        }
      }, '<i class="icon-remove"></i>'),
      errorElement: 'span',
      errorPlacement: function (error, element) {
        element.next('.msg').html(error);
      },
      submitHandler: function (form) {
        var submitButton = $('#login_submit').focus();

        if ($(form).data('busy')) {
          return false;
        }

        toggleState(submitButton, 'busy', '<i class="icon-spinner icon-large icon-spin"></i><span>登录中，请稍候…</span>');
        window.setTimeout(function () {
          toggleState(submitButton, 'idle', '登录');
        }, 3000);
        ajaxSubmit(form);
      }
    });
  }

  function setupRegisterFormValidation() {
    var $registerForm = $('#registerForm').keydown(function (e) {
      e.keyCode === 13 && submitForm();
    });

    $('#register_submit').click(submitForm);

    function submitForm() {
      $registerForm.submit();
      return false;
    }

    $registerForm.validate({
      debug: false,
      focusInvalid: true,
      // focusCleanup: false,
      onkeyup: function _(element) {
        var that = this, args = arguments;

        // 对注册邮箱和昵称作延时处理
        if (element.name === 'email' || element.name === 'nickname') {
          clearTimeout(_.timer);
          _.timer = setTimeout(function () {
            $.validator.defaults.onkeyup.apply(that, args);
          }, 400);
        } else {
          $.validator.defaults.onkeyup.apply(that, args);
        }
      },
      rules: {
        email: {
          required: true,
          email: true
        },
        nickname: {
          required: true
        },
        password: {
          required: true
        },
        password_confirm: {
          required: true,
          equalTo: '#register_password'
        },
        token_code: {
          required: true
        }
      },
      messages: prependIcon({
        email: {
          required: '注册邮箱不能为空',
          email: '请输入有效邮箱'
        },
        nickname: {
          required: '昵称不能为空',
          minlength: '请输入4-12位昵称'
        },
        password: {
          required: '请输入6-16位密码',
          minlength: '请至少输入6位密码'
        },
        password_confirm: {
          required: '请确认密码',
          equalTo: '两次输入的密码不一致'
        },
        token_code: {
          required: '验证码不能为空',
          minlength: '请输入4位验证码'
        }
      }, '<i class="icon-remove"></i>'),
      errorElement: 'span',
      errorPlacement: function (error, element) {
        element.next('.msg').html(error);
      },
      success: function (label, element) {
        label.removeClass('error').addClass('ok');

        switch (element.name) {
        case 'email':
          label.html('<i class="icon-ok"></i>恭喜，该邮箱可用！');
          break;
        case 'nickname':
          label.html('<i class="icon-ok"></i>恭喜，该昵称可用！');
          break;
        case 'password':
        case 'password_confirm':
          label.html('<i class="icon-ok">');
          break;
        }
      },
      submitHandler: function (form) {
        var submitButton = $('#register_submit').focus();

        if ($(form).data('busy')) {
          return false;
        }

        toggleState(submitButton, 'busy', '<i class="icon-spinner icon-large icon-spin"></i><span>注册中，请稍候…</span>');
        ajaxSubmit(form);
      }
    });
  }

  function init() {
    setupTabs();
    setupLoginFormValidation();
    setupRegisterFormValidation();
  }

  $(init);
}).call(this, jQuery, this, this.document);
